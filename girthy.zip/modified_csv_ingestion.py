
def ingest_compare_csv(file_path):
    csv_data = read_csv(file_path)
    valid_entries = []

    for row in csv_data:
        if row[0].startswith('1'):
            valid_entries.append(row[0])

    return valid_entries

def ingest_input_csv(file_path):
    return read_csv(file_path)
