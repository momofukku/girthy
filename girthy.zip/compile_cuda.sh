#!/bin/bash

# Compile the sha256.cu file into a shared library
nvcc -shared -o sha256.so sha256.cu

# Notify the user
echo "Compilation completed. 'sha256.so' library has been generated."
